# PDF Generator Pro - Installation Guide

## Quick Start

1. **Extract the Package**
   - Extract all files from this package to a folder on your computer
   - Remember the location of the `chrome-pdf-extension` folder

2. **Install in Chrome**
   - Open Chrome and go to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top right)
   - Click "Load unpacked"
   - Select the `chrome-pdf-extension` folder
   - The extension should now appear in your extensions list

3. **Test the Extension**
   - Open the included `test-page.html` file in Chrome
   - Click the PDF Generator Pro icon in the toolbar
   - Try generating a PDF to verify everything works

## Detailed Instructions

See the README.md file in the chrome-pdf-extension folder for complete documentation.

## Troubleshooting

- Make sure you select the `chrome-pdf-extension` folder, not the parent folder
- If the extension doesn't load, check the Chrome console for error messages
- Ensure you have Chrome 88+ for full compatibility

## Support

For issues or questions, refer to the troubleshooting section in README.md
